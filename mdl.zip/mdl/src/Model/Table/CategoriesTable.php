<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class CategoriesTable extends Table {

    public function initialize(array $config): void {
        $this->addBehavior('Timestamp');
        $this->hasMany('Championnats');
    }

    public function validationDefault(Validator $validator): validator {
        $validator
                ->notEmptyString('code', 'Veuillez entrer un code de la categorie')
                ->notEmptyString('nom', 'Veuillez entrer un nom de la categorie');

        return $validator;
    }
}
