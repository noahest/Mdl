<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class ChampionnatsTable extends Table {

    public function initialize(array $config): void {
        $this->addBehavior('Timestamp');
        $this->belongsTo('Categories');
        $this->belongsTo('Divisions');
        $this->belongsTo('TypesChampionnats');
        
    }

    public function validationDefault(Validator $validator): validator {
        $validator
                ->notEmptyString('title', 'Veuillez entrer un titre')
                ->notEmptyString('content', 'Veuillez entrer un contenue');
               

        return $validator;
    }
}
