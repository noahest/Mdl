<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class MatchsTable extends Table {

    public function initialize(array $config): void {
        $this->addBehavior('Timestamp');
        $this->belongsTo('Equipe1', [
            'className' => 'Equipes',
            'foreignKey' => 'equipe1_id',
        ]);
        $this->belongsTo('Equipe2', [
            'className' => 'Equipes',
            'foreignKey' => 'equipe2_id',
        ]);
    }

    //Les contraintes

    public function validationDefault(Validator $validator): validator {
        $validator
                //Username
                ->notEmptyString('numéro', 'Un numéro de match doit être renseigné')
                ->add('numéro', 'unique', [
                    'rule' => ['validateUnique'],
                    'message' => "Ce numéro de match n'est pas disponible.",
                    'provider' => 'table',])
                //Salle
                ->notEmptyString('salle', 'Un nom de salle doit être renseigné')
                ->add('salle', 'startWithCapital', [
                    'rule' => function ($value, $context) {
                        // Vérifiez si le nom commence par une majuscule
                        return ctype_upper(substr($value, 0, 1));
                    },
                    'message' => 'Le nom de la salle doit commencer par une majuscule.',
                ])
                ->add('nom', 'alphaOnly', [
                    'rule' => function ($value, $context) {
                        // Vérifiez si le nom ne contient que des lettres (pas de chiffres ni de caractères spéciaux)
                        return preg_match('/^[A-Za-z]+$/', $value) === 1;
                    },
                    'message' => 'Le nom de la salle ne peut contenir que des lettres (pas de chiffres ni de caractères spéciaux).',
                ])
                            ->notEmptyString('date', 'Une date doit être renseigné')
        //Equipes
            ->add('equipe1_id', 'differentTeams', [
                'rule' => function ($value, $context) {
                    $equipe2Id = $context['data']['equipeAway_id'] ?? null;

                    // Vérifiez si les équipes "home" et "away" sont différentes
                    return $value !== $equipe2Id;
                },
                'message' => 'Les équipes "home" et "away" ne peuvent pas être les mêmes.',
            ]);

        return $validator;
    }
}
