<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

class EquipesTable extends Table {

    public function initialize(array $config): void {
        $this->addBehavior('Timestamp');
        $this->belongsTo('Clubs');
        $this->hasMany('Matchs');
        
       
    }

    public function validationDefault(Validator $validator): validator {
        $validator
                ->notEmptyString('code', 'Veuillez entrer un code de la categorie')
                ->notEmptyString('nom', 'Veuillez entrer un nom de la categorie');

        return $validator;
    }
}
