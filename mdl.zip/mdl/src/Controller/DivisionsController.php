<?php

namespace App\Controller;

class DivisionsController extends AppController {

    public function index() {
//on récupére tous les posts et on les stocke dans $mesArticles
       $mesDivisions = $this->Divisions->find('all')->contain([
             'Championnats' => function ($q) {
                        return $q
                                ->select(['division_id']);

             }]) ->all();
       
        $this->set(compact('mesDivisions')); //envoie à la vue le contenu de $mesArticles dans $rep qui sera utiliseable
    }

    


    public function add() {

        $leNewDivision = $this->Divisions->newEmptyEntity();
        if ($this->request->is('post')) {
            $leNewDivision = $this->Divisions->patchEntity($leNewDivision, $this->request->getData());
            if ($this->Divisions->save($leNewDivision)) {
                $this->Flash->success(__("La division a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter la division."));
        }
        $this->set(compact('leNewDivision'));
    }
    
    public function edit($id = null) {
        try {
            $leDivision = $this->Divisions->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("La division edit doit être appelé avec un identifiant"));
            } else {
                $this->Flash->error(__("La cdivision {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }
        if ($this->request->is(['post', 'put'])) {
            $this->Divisions->patchEntity($leDivision, $this->request->getData());
            if ($this->Divisions->save($leDivision)) {
                $this->Flash->success(__('Votre division a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre division.'));
        }
        $this->set(compact('leDivision'));
    }
    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leDivision = $this->Divisions->get($id);
        if ($this->Divisions->delete($leDivision)) {
            $this->Flash->success(__("La division {0} d' id {1} a bien été supprimé ! ", $leDivision->code, $leDivision->id));
            return $this->redirect(['action' => 'index']);
        }
    }
    
    
}
