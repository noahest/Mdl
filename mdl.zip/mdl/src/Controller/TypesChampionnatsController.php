<?php
declare(strict_types=1);
namespace App\Controller;

class TypesChampionnatsController extends AppController {

    public function index() {
        //on récupére toute les types et on les stocke dans $mesTypes 
        $mesTypes = $this->TypesChampionnats->find()->all();
        $this->set(compact('mesTypes'));
    }

    public function add() {


        $mesTypes = $this->TypesChampionnats->newEmptyEntity();
//On créer un enregistrement de type vide
        if ($this->request->is('post')) {
            $mesTypes = $this->TypesChampionnats->patchEntity($mesTypes, $this->request->getData());
            if ($this->TypesChampionnats->save($mesTypes)) {
                $this->Flash->success(__("Le type a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter votre type."));
        }
        $this->set(compact('mesTypes'));
    }

    public function edit($id = null) {

        try {
            $mesTypes = $this->TypesChampionnats->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("L'action edit doit être appelé avec un identifiant"));
            } else {
                $this->Flash->error(__("Le type {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }

        if ($this->request->is(['post', 'put'])) {
            $this->TypesChampionnats->patchEntity($mesTypes, $this->request->getData());
            if ($this->TypesChampionnats->save($mesTypes)) {
                $this->Flash->success(__('Votre type a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre type.'));
        }
        $this->set(compact('mesTypes'));
    }
    
     Public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $mesTypes = $this->TypesChampionnats->get($id);
        if ($this->TypesChampionnats->delete($mesTypes)) {
            $this->Flash->success(__("Le type {0} d' id {1} a bien été supprimé ! ", $mesTypes->TypesChampionnats, $mesTypes->id));
            return $this->redirect(['action' => 'index']);
        }
    }
}
