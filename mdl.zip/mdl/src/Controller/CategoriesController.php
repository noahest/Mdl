<?php

namespace App\Controller;

class CategoriesController extends AppController {

    public function index() {
//on récupére tous les posts et on les stocke dans $mesArticles
        $mesCategories = $this->Categories->find('all')->contain([
            'Championnats' =>function($q){
            return $q
                    ->select(['category_id']);
            } 
            ])->all();
        $this->set(compact('mesCategories')); //envoie à la vue le contenu de $mesArticles dans $rep qui sera utiliseable
    }

    public function add() {

        $leNewCategorie = $this->Categories->newEmptyEntity();
        if ($this->request->is('post')) {
            $leNewCategorie = $this->Categories->patchEntity($leNewCategorie, $this->request->getData());
            if ($this->Categories->save($leNewCategorie)) {
                $this->Flash->success(__("La categorie a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter la categorie."));
        }
        $this->set(compact('leNewCategorie'));
    }
    
    public function edit($id = null) {
        try {
            $leCategorie = $this->Categories->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("La catégorie edit doit être appelé avec un identifiant"));
            } else {
                $this->Flash->error(__("La catégorie {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }
        if ($this->request->is(['post', 'put'])) {
            $this->Categories->patchEntity($leCategorie, $this->request->getData());
            if ($this->Categories->save($leCategorie)) {
                $this->Flash->success(__('Votre categorie a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre categorie.'));
        }
        $this->set(compact('leCategorie'));
    }
    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leCategorie = $this->Categories->get($id);
        if ($this->Categories->delete($leCategorie)) {
            $this->Flash->success(__("La categorie {0} d' id {1} a bien été supprimé ! ", $leCategorie->code, $leCategorie->id));
            return $this->redirect(['action' => 'index']);
        }
    }
    
    
}
