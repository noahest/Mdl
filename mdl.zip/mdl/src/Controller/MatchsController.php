<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

namespace App\Controller;

class MatchsController extends AppController {

    public function index() {
        $mesMatchs = $this->Matchs->find('all')->contain([
                    'Equipe1' => function ($q) {
                        return $q
                                ->select(['nom']);
                    },
                    'Equipe2' => function ($q) {
                        return $q
                                ->select(['nom']);
                    }
                ])->all();
        //envoie à la vue le contenu de $mesClubs dans $rep qui sera utiliseable
        $this->set(compact('mesMatchs'));
    }

   

    public function add() {
        $leNewMatch = $this->Matchs->newEmptyEntity();
        //Nom du rôle
        $equipe1 = $this->Matchs->Equipe1->find('list', limit: 200)->all();
        $equipe2 = $this->Matchs->Equipe2->find('list', limit: 200)->all();
        if ($this->request->is('post')) {
            $leNewMatch = $this->Matchs->patchEntity($leNewMatch, $this->request->getData());
            if ($this->Matchs->save($leNewMatch)) {
                $this->Flash->success(__("Le matchs a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter votre matchs."));
        }
        $this->set(compact('leNewMatch', 'equipe1', 'equipe2'));
    }

    public function edit($id = null) {
        try {
            $leMatch = $this->Matchs->get($id);
            $equipe1 = $this->Matchs->Equipe1->find('list', limit: 200)->all();
            $equipe2 = $this->Matchs->Equipe2->find('list', limit: 200)->all();
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("L'action detail doit être appelée avec un identifiant"));
            } else {
                $this->Flash->error(__("Le match {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }

        if ($this->request->is(['post', 'put'])) {
            $this->Matchs->patchEntity($leMatch, $this->request->getData());
            if ($this->Matchs->save($leMatch)) { // Correction ici, utilisez $this->Matchs
                $this->Flash->success(__('Votre match a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('Impossible de mettre à jour votre match.'));
            }
        }

        $this->set(compact('leMatch', 'equipe1', 'equipe2'));
    }

    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leMatch = $this->Matchs->get($id);
        if ($this->Matchs->delete($leMatch)) {
            $this->Flash->success(__("Le match {0} d' id {1} a bien été supprimé ! ", $leMatch->nom, $leMatch->id));
            return $this->redirect(['action' => 'index']);
        }
    }
}
