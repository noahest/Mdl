<?php

namespace App\Controller;

class EquipesController extends AppController {

    public function index() {
//on récupére tous les posts et on les stocke dans $mesArticles
        $mesEquipes = $this->Equipes->find('all')->contain([
            'Clubs' =>function($q){
            return $q
                    ->select(['nom']);
            }
        ]);
        $this->set(compact('mesEquipes')); //envoie à la vue le contenu de mesEquipes dans $rep qui sera utiliseable
    }

    public function add() {

        $leNewEquipe = $this->Equipes->newEmptyEntity();
        
        $lesClubs = $this->fetchTable('Clubs')->find('list', ['valueField' => 'nom'
        ]);
        $lesClubs = $lesClubs->toArray();
        if ($this->request->is('post')) {
            $leNewEquipe = $this->Equipes->patchEntity($leNewEquipe, $this->request->getData());
            if ($this->Equipes->save($leNewEquipe)) {
                $this->Flash->success(__("L'equipe a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter l/'equipe."));
        }
        $this->set(compact('leNewEquipe', 'lesClubs'));
    }
    
    public function edit($id = null) {
        try {
            $leEquipe = $this->Equipes->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("L'équipe edit doit être appelé avec un identifiant"));
            } else {
                $this->Flash->error(__("L'équipe {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }
        
         $lesClubs = $this->fetchTable('Clubs')->find('list', ['valueField' => 'nom'
        ]);
        $lesClubs = $lesClubs->toArray();
        if ($this->request->is(['post', 'put'])) {
            $this->Equipes->patchEntity($leEquipe, $this->request->getData());
            if ($this->Equipes->save($leEquipe)) {
                $this->Flash->success(__('Votre equipe a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre equipe.'));
        }
        $this->set(compact('leEquipe', 'lesClubs'));
    }
    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leEquipe = $this->Equipes->get($id);
        if ($this->Equipes->delete($leEquipe)) {
            $this->Flash->success(__("L'equipe {0} d' id {1} a bien été supprimé ! ", $leEquipe->code, $leEquipe->id));
            return $this->redirect(['action' => 'index']);
        }
    }
    
     
}
