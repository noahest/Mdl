<?php

namespace App\Controller;

class ClubsController extends AppController {

    public function index() {

        $mesClubs = $this->Clubs->find()->all();
        $this->set(compact('mesClubs')); //envoie à la vue le contenu de $mesArticles dans $rep qui sera utiliseable
    }

    public function add() {

        $leNewClub = $this->Clubs->newEmptyEntity();
        if ($this->request->is('post')) {
            $leNewClub = $this->Clubs->patchEntity($leNewClub, $this->request->getData());
            if ($this->Clubs->save($leNewClub)) {
                $this->Flash->success(__("Le club a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter le club."));
        }
        $this->set(compact('leNewClub'));
    }
    
    public function edit($id = null) {
        try {
            $leClub = $this->Clubs->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("Le club doit être avec un identifiant"));
            } else {
                $this->Flash->error(__("Le club {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }
        if ($this->request->is(['post', 'put'])) {
            $this->Clubs->patchEntity($leClub, $this->request->getData());
            if ($this->Clubs->save($leClub)) {
                $this->Flash->success(__('Votre cluba été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre club.'));
        }
        $this->set(compact('leClub'));
    }
    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leClub = $this->Clubs->get($id);
        if ($this->Clubs->delete($leClub)) {
            $this->Flash->success(__("Le club {0} : {1} a bien été supprimé ! ", $leClub->code, $leClub->id));
            return $this->redirect(['action' => 'index']);
        }
    }
    
    
}
