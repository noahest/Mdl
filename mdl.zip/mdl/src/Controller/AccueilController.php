<?php

namespace App\Controller;

class AccueilController extends AppController {

    public function index() {

    }
    
}