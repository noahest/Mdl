<?php

namespace App\Controller;

class HistoCategoriesController extends AppController {

    public function index() {
//on récupére tous les users et on les stocke dans $mesUsers
        $mesHCategories = $this->HistoCategories->find()->all();
        $this->set(compact('mesHCategories')); //envoie à la vue le contenu de $mesHCategories
    }
}



