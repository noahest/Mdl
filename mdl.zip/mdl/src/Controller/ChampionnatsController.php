<?php

namespace App\Controller;

class ChampionnatsController extends AppController {

    public function index() {
        $mesChampionnats = $this->Championnats->find('all')->contain([
                    'Divisions' => function ($q) {
                        return $q
                                ->select(['name']);
                        },
                    'Categories' => function ($q) {
                        return $q
                                ->select(['nom']);
                        
                        },
                    'TypesChampionnats' => function ($q) {
                        return $q
                                ->select(['name']);
                      
                    }])->all();
        $this->set(compact('mesChampionnats'));

        //envoie à la vue le contenu de $mesArticles dans $rep qui sera utiliseable
    }

    public function add() {

        $leNewChampionnat = $this->Championnats->newEmptyEntity();
        
        $lesDivisions = $this->fetchTable('Divisions')->find('list', ['valueField' => 'name'
        ]);
        $lesDivisions = $lesDivisions->toArray();
        
        
        $lesCategories = $this->fetchTable('Categories')->find('list', ['valueField' => 'nom'
        ]);
        $lesCategories = $lesCategories->toArray();
        
        $lesTypesChampionnats = $this->fetchTable('TypesChampionnats')->find('list', ['valueField' => 'name'
        ]);
        $lesTypesChampionnats = $lesTypesChampionnats->toArray();
        
        if ($this->request->is('post')) {
            $leNewchampionnat = $this->Championnats->patchEntity($leNewChampionnat, $this->request->getData());
            if ($this->Championnats->save($leNewChampionnat)) {
                $this->Flash->success(__("Le championnat a été sauvegardé."));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__("Impossible d'ajouter le championnat."));
        }
        $this->set(compact('leNewChampionnat', 'lesDivisions', 'lesCategories', 'lesTypesChampionnats'));
    }

    public function edit($id = null) {
        try {
            $leChampionnat = $this->Championnats->get($id);
        } catch (\Exception $ex) {
            if ($id == null) {
                $this->Flash->error(__("La fonction edit doit être appelé avec un identifiant"));
            } else {
                $this->Flash->error(__("Le championnat {0} n'existe pas", $id));
            }
            return $this->redirect(['action' => 'index']);
        }
        if ($this->request->is(['post', 'put'])) {
            $this->Championnats->patchEntity($leChampionnat, $this->request->getData());
            if ($this->Championnats->save($leChampionnat)) {
                $this->Flash->success(__('Votre championnat a été mis à jour.'));
                return $this->redirect(['action' => 'index']);
            } else
                $this->Flash->error(__('Impossible de mettre à jour votre championnat.'));
        }
        $this->set(compact('leChampionnat'));
    }

    public function delete($id) {
        $this->request->allowMethod(['post', 'delete']);
        $leChampionnat = $this->Championnats->get($id);
        if ($this->Championnats->delete($leChampionnat)) {
            $this->Flash->success(__("Le championnat {0} d' id {1} a bien été supprimé ! ", $leChampionnat->code, $leChampionnat->id));
            return $this->redirect(['action' => 'index']);
        }
    }
    
      public function pdf() {
        $this->viewBuilder()->enableAutoLayout(false);
        $mesChampionnats = $this->Championnats->find('all')->contain([
                    'Divisions' => function ($q) {
                        return $q
                                ->select(['name']);
                    },
                    'Categories' => function ($q) {
                        return $q
                                ->select(['nom']);
                    },
                    'TypesChampionnats' => function ($q) {
                        return $q
                                ->select(['name']);
                    }])->all();
        $this->viewBuilder()->setClassName('CakePdf.Pdf');
        $this->viewBuilder()->setOption(
                'pdfConfig',
                [
                    'orientation' => 'portrait',
                    'download' => true, // This can be omitted if "filename" is specified.
                    'filename' => 'championnat_.pdf' //// This can be omitted if you want file name based on URL.
                ]
        );
       $this->set(compact('mesChampionnats'));
    }


}
