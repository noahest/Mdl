<h1>Touts les clubs</h1>
<table>
    <tr>
        <th>code</th>
        <th>nom</th>
        <th>Date de cr&eacute;ation</th>
        <th>Date de modificataion</th>
        <th>Actions</th>
    </tr>


    <!-- Ici se trouve l'itération sur l'objet query de notre $mesArticles, l'affichage des infos des articles -->
    <?php foreach ($mesClubs as $club): ?>
        <tr>
            <td><?= $club->code ?></td>
            <td><?= $club->nom ?></td>
            <td><?= $club->created->format(DATE_RFC850) ?></td>
            <td><?= $club->modified->format(DATE_RFC850) ?></td>

            <td>

                <?php
                echo $this->Html->link(
                        $this->Html->image('edit.png', ['alt' => "Edit", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
                        ['controller' => 'clubs', 'action' => "edit", $club->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
                );
                ?>


                <?=
                $this->Form->postLink(
                        $this->Html->image('delete.png', ['alt' => 'Modifier', 'width' => 40, 'height' => 40]),
                        ['action' => 'delete', $club->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none',
                            'confirm' => __("Vraiment supprimer le club {0} : {1} ", $club->code, $club->nom)]
                )
                ?>





        </tr>

    <?php endforeach; ?>

    <?php
    echo $this->Html->link(
            $this->Html->image('add.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
            ['controller' => 'clubs', 'action' => "add"],
            ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
    );
    ?>

</table>

