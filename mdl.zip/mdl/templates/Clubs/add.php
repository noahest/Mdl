<h1>Ajouter un Club</h1>
<?php
echo $this->Form->create($leNewClub);
echo $this->Form->control('code' ,
         ['label' => 'Code du club']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('nom', ['rows' => '3', 'label' => 'Nom du club']);
echo $this->Form->button(__("Sauvegarder le club"));
echo $this->Form->end();
?>

<?=
$this->Html->link(
        $this->Html->image('retour.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
        ['controller' => 'clubs', 'action' => "index"],
        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
);
?>

