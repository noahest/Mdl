<h1>Modifier le club</h1>
<?php
echo $this->Form->create($leClub);
echo $this->Form->control('code' ,
         ['label' => 'Code du club']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('nom', ['rows' => '3', 'label' => 'Nom du club']);
echo $this->Form->button(__("Modifier le club"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des categories" , [
    'controller' => 'clubs','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

