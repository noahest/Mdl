<h1>Ajouter un championnat</h1>
<?php
echo $this->Form->create($leNewChampionnat);
echo $this->Form->control('code' ,
         ['label' => 'Code du championnat']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('name', ['rows' => '3', 'label' => 'Nom du championnat']);
echo $this->Form->control('division_id', ['options' => $lesDivisions, 'label' => 'Selectionnez une division']);
echo $this->Form->control('category_id', ['options' => $lesCategories, 'label' => 'Selectionnez une catégorie']);
echo $this->Form->control('types_championnat_id', ['options' => $lesTypesChampionnats, 'label' => 'Selectionnez une type de championnats']);
echo $this->Form->button(__("Ajouter le championnat"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des championnats" , [
    'controller' => 'championnats','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

