<h1>Modifier le championnat</h1>
<?php
echo $this->Form->create($leChampionnat);
echo $this->Form->control('code' ,
         ['label' => 'Code du championnat']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('name', ['rows' => '3', 'label' => 'Nom de le championnat']);
echo $this->Form->button(__("Modifier le championnat"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des championnats" , [
    'controller' => 'divisions','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

