<!DOCTYPE html>
<html>
<head>
<title>PDF</title>
<style>
@page {
    
    margin: 0px 0px 0px 0px !important;
    padding: 0px 0px 0px 0px !important;
}
</style>
</head>
<body>
    <h1> Tous les championnats</h1>
<table>
    <tr>
        <th>code</th>
        <th>nom</th>
        <th>Division</th>
        <th>Categorie</th>
        <th>type de championnat</th>
       
       
        <th>Date de cr&eacute;ation</th>
        <th>Date de modificataion</th>
        
    </tr>

    <!-- Ici se trouve l'itération sur l'objet query de notre $mesArticles, l'affichage des infos des articles -->
    <?php foreach ($mesChampionnats as $championnat): ?>
        <tr>
            <td><?= $championnat->code ?></td>
            <td><?= $championnat->name ?></td>
            <td><?= $championnat->division->name?></td>
            <td><?= $championnat->category->nom ?></td>
            <td><?= $championnat->types_championnat->name?></td>
            
            
            
            <td><?= $championnat->created->format(DATE_RFC850) ?></td>
            <td><?= $championnat->modified->format(DATE_RFC850) ?></td>

           

                

        </tr>

    <?php endforeach; ?>


</table>
</body>
</html>
