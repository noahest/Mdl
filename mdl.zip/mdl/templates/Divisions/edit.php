<h1>Modifier la division</h1>
<?php
echo $this->Form->create($leDivision);
echo $this->Form->control('code' ,
         ['label' => 'Code de la division']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('name', ['rows' => '3', 'label' => 'Nom de la division']);
echo $this->Form->button(__("Modifier la division"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des divisions" , [
    'controller' => 'divisions','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

