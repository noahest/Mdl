<h1>Ajouter une division</h1>
<?php
echo $this->Form->create($leNewDivision);
echo $this->Form->control('code' ,
         ['label' => 'Code de la division']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('name', ['rows' => '3', 'label' => 'Nom de la division']);
echo $this->Form->button(__("Sauvegarder la division"));
echo $this->Form->end();
?>

<?=
$this->Html->link(
        $this->Html->image('retour.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
        ['controller' => 'divisions', 'action' => "index"],
        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
);
?>

