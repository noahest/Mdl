<h1>Modifier la categorie</h1>
<?php
echo $this->Form->create($leCategorie);
echo $this->Form->control('code' ,
         ['label' => 'Code de la categorie']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('nom', ['rows' => '3', 'label' => 'Nom de la categorie']);
echo $this->Form->button(__("Modifier la categorie"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des categories" , [
    'controller' => 'categories','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

