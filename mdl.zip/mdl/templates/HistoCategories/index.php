<h1>L'historique de categorie</h1>

<table>
    <tr>
       
        <th>act</th>
        <th>ancien code</th>
        <th>nouveau code</th>
        <th>ancien nom</th>
        <th>nouveau nom</th>
        <th>date</th>    
    </tr>

    <!-- Ici se trouve l'itération sur l'objet query de notre $mesUsers, l'affichage des infos des users -->
    <?php foreach ($mesHCategories as $HistoCategorie): ?>
        <tr>
            
            <td><?= $HistoCategorie->act ?></td>
            <td><?= $HistoCategorie->oldcode ?></td>
            <td><?= $HistoCategorie->newcode ?></td>
            <td><?= $HistoCategorie->oldnom ?></td>
            <td><?= $HistoCategorie->newnom ?></td>
            <td><?= $HistoCategorie->date->format(DATE_RFC850) ?></td>  
            
           
        </tr>

        
    <?php endforeach; ?>
 
</table>
<?=
$this->Html->link(
        $this->Html->image('retour.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
        ['controller' => 'categories', 'action' => "index"],
        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
);
?>