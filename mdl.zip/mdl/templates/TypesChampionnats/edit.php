<h1>Modifier le type championnats</h1>
<?php
echo $this->Form->create($mesTypes);
echo $this->Form->control('name'
        , ['label' => 'Type de championnat']);// permet de changer le type

echo $this->Form->button(__("Sauvegarder le type"));
echo $this->Form->end();
?>
<?=
$this->Html->link("Aller a la page index",
        ['controller' => 'TypesChampionnats', 'action' => 'index'],
        ['class' => 'button']);
?>

