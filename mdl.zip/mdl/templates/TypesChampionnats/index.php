<h1>Tous les types de championnat</h1>
<table>
    <tr>
        <th>Id</th>
        <th>nom</th>
        
       
        <th>Date de modification</th>
        <th>Date de cr&eacute;ation</th>
        <th>modifier</th>
        <th>supprimer</th>
        
    </tr>

    <!-- Ici se trouve l'itération sur l'objet query de notre $mesDivisions, l'affichage des infos des articles -->
    <?php foreach ($mesTypes as $type): ?>
        <tr>
            <td><?= $type->id ?></td>
            <td><?= $type->name ?></td>
            
     
            </td>
            
            <td><?= $type->modified->format(DATE_RFC850) ?></td>
            <td><?= $type->created->format(DATE_RFC850) ?></td>
            
            <td>  <?php
                echo $this->Html->link(
                        $this->Html->image('edit.png', ['alt' => "edit", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
                        ['controller' => 'types-championnats', 'action' => "edit", $type->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
                );

               
                ?>
            <td>
                <?=
                $this->Form->postLink(
                        $this->Html->image('delete.png', ['alt' => 'Modifier', 'width' => 40, 'height' => 40]),
                        ['action' => 'delete', $type->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none',
                            'confirm' => __("Vraiment supprimer le type championnat {0} dont l'id vaut {1}",  $type->type, $type->id)]
                )
                ?>

            </td>

        </tr>
            <?php endforeach; ?>

            <?php
            echo $this->Html->link(
                    $this->Html->image('add.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
                    ['controller' => 'types-championnats', 'action' => "add"],
                    ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
            );
            ?>

</table>
