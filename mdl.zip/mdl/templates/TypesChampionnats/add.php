
<h1>Ajouter un type de championnat</h1>
<?php
echo $this->Form->create($mesTypes);
echo $this->Form->control('code'
        , ['label' => 'Code']);
echo $this->Form->control('name'
        , ['label' => 'Nom']);

echo $this->Form->button(__("Sauvegarder le type"));
echo $this->Form->end();
?>
<?=
$this->Html->link("Aller a la page index",
        ['controller' => 'TypesChampionats', 'action' => 'index'],
        ['class' => 'button']);
?>
