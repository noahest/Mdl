<h1>Ajouter un match</h1>
<?php
echo $this->Form->create($leNewMatch);
echo $this->Form->control('code',
        ['label' => 'Numéro du match']);
echo $this->Form->control('nom',
        ['label' => 'Lieu du match']);

echo $this->Form->control('equipe1_id',
    	['options' => $equipe1,
        	'label' => 'Sélectionnez un']);
echo $this->Form->control('equipe2_id',
    	['options' => $equipe2,
        	'label' => 'Sélectionnez un']);
echo $this->Form->control('date', [
    'label' => 'Date du match',
    'type' => 'date'
]);
echo $this->Form->button(__("Sauvegarder le match"));
echo $this->Form->end();
?>

<?=
//Bouton
//Il y a 3 paramètre
//1- nom du lien
$this->Html->link("Retourner a liste des matchs",
        //2- adresse ou on veut aller(tableau)
        ['controller' => 'matchs', 'action' => 'index'],
        //3-CSS (tableau)
        ['class' => 'button']);
?>