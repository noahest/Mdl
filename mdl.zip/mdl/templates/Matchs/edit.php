<h1>Modifier un match</h1>
<?php
echo $this->Form->create($leMatch);
echo $this->Form->control('code',
        ['label' => 'Numéro du match']);
echo $this->Form->control('nom',
        ['label' => 'Lieu du match']);
echo $this->Form->button(__("Modifier le match"));
echo $this->Form->end();
?>

<?=
//Bouton
//Il y a 3 paramètre
//1- nom du lien
$this->Html->link("Retourner a liste des équipes",
        //2- adresse ou on veut aller(tableau)
        ['controller' => 'equipes', 'action' => 'index'],
        //3-CSS (tableau)
        ['class' => 'button']);
?>