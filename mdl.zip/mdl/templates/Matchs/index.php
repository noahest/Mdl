<h1>Touts les matchs</h1>
<table>
    <tr>
        <th>code</th>
        <th>nom</th>
        <th>Equipe 1</th>
        <th>Equipe 2</th>
        <th>Date du matchs</th>
        <th>Date de cr&eacute;ation</th>
        <th>Date de modificataion</th>
        <th>Actions</th>
    </tr>


    <!-- Ici se trouve l'itération sur l'objet query de notre $mesArticles, l'affichage des infos des articles -->
    <?php foreach ($mesMatchs as $match): ?>
        <tr>
            <td><?= $match->code ?></td>
            <td><?= $match->nom?></td>
            <td><?= $match->equipe1->nom ?></td>
            <td><?= $match->equipe2->nom ?></td>
            <td><?= $match->date?></td>
           
            
            
            
            <td><?= $match->created->format(DATE_RFC850) ?></td>
            <td><?= $match->modified->format(DATE_RFC850) ?></td>

            <td>

                <?php
                echo $this->Html->link(
                        $this->Html->image('edit.png', ['alt' => "Edit", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
                        ['controller' => 'matchs', 'action' => "edit", $match->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
                );
                ?>


                <?=
                $this->Form->postLink(
                        $this->Html->image('delete.png', ['alt' => 'Modifier', 'width' => 40, 'height' => 40]),
                        ['action' => 'delete', $match->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none',
                            'confirm' => __("Vraiment supprimer l'utilisateur {0} dont l'id vaut {1} ", $match->code, $match->nom)]
                )
                ?>





        </tr>

    <?php endforeach; ?>

    <?php
    echo $this->Html->link(
            $this->Html->image('add.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
            ['controller' => 'matchs', 'action' => "add"],
            ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
    );
    ?>

</table>

