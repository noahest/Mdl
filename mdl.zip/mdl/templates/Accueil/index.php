<h1>Bienvenue dans la maison des ligues</h1>
<?=
$this->Html->link("Divisions ",
        ['controller' => 'divisions', 'action' => 'index'],
        ['class' => 'button'])
;
?>

<?=
$this->Html->link("Types de championnats ",
        ['controller' => 'types-championnats', 'action' => 'index'],
        ['class' => 'button'])
;
?>

<?=
$this->Html->link("Championnat ",
        ['controller' => 'championnats', 'action' => 'index'],
        ['class' => 'button'])
;
?>

<?=
$this->Html->link("Matchs ",
        ['controller' => 'matchs', 'action' => 'index'],
        ['class' => 'button'])
;

?>

<?=
$this->Html->link("Categorie ",
        ['controller' => 'categories', 'action' => 'index'],
        ['class' => 'button'])
;

?>

<?=
$this->Html->link("Club ",
        ['controller' => 'clubs', 'action' => 'index'],
        ['class' => 'button'])
;
?>

<?=
$this->Html->link("Equipe ",
        ['controller' => 'equipes', 'action' => 'index'],
        ['class' => 'button'])
;
?>
