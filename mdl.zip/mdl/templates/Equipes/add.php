<h1>Ajouter une equipe</h1>
<?php
echo $this->Form->create($leNewEquipe);
echo $this->Form->control('nom' ,
         ['label' => 'Nom de l"equipe']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('club_id', ['options' => $lesClubs, 'label' => 'Selectionnez un club']);
echo $this->Form->button(__("Sauvegarder l'equipe"));
echo $this->Form->end();
?>

<?=
$this->Html->link(
        $this->Html->image('retour.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
        ['controller' => 'equipes', 'action' => "index"],
        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
);
?>

