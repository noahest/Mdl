<h1>Modifier l'equipe</h1>
<?php
echo $this->Form->create($leEquipe);
echo $this->Form->control('nom' ,
         ['label' => 'Code du equipe']);
//le label permet de changer len nom de l'attribut souhaité
echo $this->Form->control('club_id', ['options' => $lesClubs, 'label' => 'Selectionnez un club']);
echo $this->Form->button(__("Modifier le equipe"));
echo $this->Form->end();
?>

<?=
$this->html->link("Retour à la liste des championnats" , [
    'controller' => 'equipes','action' => 'index',], ['class' => 'button']);
//l’url généré sera de la forme /articles/detail/…
?>

