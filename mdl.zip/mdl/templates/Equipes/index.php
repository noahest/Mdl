<h1>Toutes les equipes</h1>
<table>
    <tr>
        <th>nom</th>
        <th>Club</th>
        <th>Date de cr&eacute;ation</th>
        <th>Date de modificataion</th>
        <th>Actions</th>
    </tr>


    <!-- Ici se trouve l'itération sur l'objet query de notre $mesArticles, l'affichage des infos des articles -->
    <?php foreach ($mesEquipes as $equipe): ?>
        <tr>
            <td><?= $equipe->nom?></td>
            <td><?= $equipe->club->nom ?></td>
            <td><?= $equipe->created->format(DATE_RFC850) ?></td>
            <td><?= $equipe->modified->format(DATE_RFC850) ?></td>

            <td>

                <?php
                echo $this->Html->link(
                        $this->Html->image('edit.png', ['alt' => "Edit", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
                        ['controller' => 'equipes', 'action' => "edit", $equipe->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
                );
                ?>


                <?=
                $this->Form->postLink(
                        $this->Html->image('delete.png', ['alt' => 'Modifier', 'width' => 40, 'height' => 40]),
                        ['action' => 'delete', $equipe->id],
                        ['escape' => false, 'style' => 'background-color: transparent; border: none',
                            'confirm' => __("Vraiment supprimer la division {0} dont l'id vaut {1} ", $equipe->code, $equipe->nom)]
                )
                ?>





        </tr>

    <?php endforeach; ?>

    <?php
    echo $this->Html->link(
            $this->Html->image('add.png', ['alt' => "ajouter", 'width' => 40, 'height' => 40]), // Recherche dans le dossier webroot/img
            ['controller' => 'equipes', 'action' => "add"],
            ['escape' => false, 'style' => 'background-color: transparent; border: none'] // Ceci pour indiquer de ne pas échapper les caractères HTML du lien vu qu'ici tu as une image
    );
    ?>

</table>

