<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class AlterTableMatchs extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change(): void
    {
        $table = $this->table('matchs');
        $table->addColumn('equipe1_id', 'integer', ['signed' => false]);
        $table->addColumn('equipe2_id', 'integer', ['signed' => false]);
        $table->save();
         
        $table2 = $this->table('matchs');
        $table2->addForeignKey('equipe1_id', 'equipes', 'id');
        $table2->addForeignKey('equipe2_id', 'equipes', 'id');
        $table2->save();
    }
}
