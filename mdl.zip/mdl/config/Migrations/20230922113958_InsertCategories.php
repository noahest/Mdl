<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class InsertCategories extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
     public function up(): void
    { $this->execute("INSERT INTO categories (code, nom, created, modified) VALUES"
            ."('m1','minime', NOW(),NOW())");
    
      $this->execute("INSERT INTO categories (code, nom, created, modified) VALUES"
            ."('c1','cadet',NOW(),NOW())");
      
      $this->execute("INSERT INTO categories (code, nom, created, modified) VALUES"
            ."('s1','senior',NOW(),NOW())");
      
      
    
    }
    public function down(): void
    {
        $this->execute("delete from categories");
    }
}
