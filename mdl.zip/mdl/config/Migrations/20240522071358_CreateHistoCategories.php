<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class CreateHistoCategories extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change(): void
    {
        $table = $this->table('histo_categories');
        $table->addColumn('act', 'string', [
           
            'limit' => 255,
            
        ]);
        $table->addColumn('oldcode', 'string', [
            
            'limit' => 255,
            
        ]);
        $table->addColumn('newcode', 'string', [
            
            'limit' => 255,
            
        ]);
        $table->addColumn('oldnom', 'string', [
            
            'limit' => 255,
            
        ]);
        $table->addColumn('newnom', 'string', [
            
            'limit' => 255,
           
        ]);
    
    
        $table->addColumn('date', 'datetime', [
           
            
        ]);
        $table->create();
    }
}
