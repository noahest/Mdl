<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class CreateEquipes extends AbstractMigration
{
    
    public function change(): void
    {
        
    $table = $this->table('equipes');
    $table->addColumn('club_id', 'integer', ['signed' => false]);
    $table->addColumn('nom', 'string');
    $table->addColumn('created', 'datetime', [
           'default' => null,
           'null' => false,
        ]);
    $table->addColumn('modified', 'datetime', [
           'default' => null,
           'null' => false,
        ]);
    $table->addForeignKey('club_id', 'clubs', 'id');
    $table->create();
    }  
}
