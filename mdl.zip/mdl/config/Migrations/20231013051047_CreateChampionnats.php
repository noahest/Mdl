<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class CreateChampionnats extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function change(): void
    {
        $table = $this->table('championnats');
        $table->addColumn('code', 'string', [
            'default' => null,
            'limit' => 255,
            'null' => false,
        ]);
        $table->addColumn('name', 'string', [
            'default' => null,
            'limit' => 255,
            'null' => false,
        ]);
        $table->addColumn('created', 'datetime', [
            'default' => null,
            'null' => false,
        ]);
        $table->addColumn('modified', 'datetime', [
            'default' => null,
            'null' => false,
        ]);
        
         
        
        

        
        
        
        
        
        $table->addColumn('division_id', 'integer', ['signed' => false]);
        $table->addColumn('category_id', 'integer', ['signed' => false]);
        $table->addColumn('types_championnat_id', 'integer',['signed' => false]);
        $table->create();
         $table2 = $this->table('championnats');
                $this->execute(
                'UPDATE championnats SET types_championnat_id = (select id from types_championnats limit 1)'
                );
              
             
        $table2->addForeignKey('types_championnat_id', 'types_championnats', 'id');        
        $table2->addForeignKey('division_id', 'divisions', 'id');
        $table2->addForeignKey('category_id', 'categories', 'id');
        
        $table2->save();
    }
}
