<?php
declare(strict_types=1);

use Migrations\AbstractMigration;

class CreateTrigger extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * https://book.cakephp.org/phinx/0/en/migrations.html#the-change-method
     * @return void
     */
    public function up(): void
    {
        
        $this->execute("CREATE OR REPLACE FUNCTION after_update_category()
        RETURNS TRIGGER 
        AS $$
        BEGIN
        IF TG_OP='INSERT' THEN
        INSERT INTO histo_categories(act, oldcode, newcode, oldnom, newnom, date)
        VALUES('INSERT', NULL, NEW.code, NULL, NEW.nom, NOW());
        
        ELSIF TG_OP='UPDATE' THEN
        INSERT INTO histo_categories(act, oldcode, newcode, oldnom, newnom, date)
        VALUES('UPDATE', OLD.code, NEW.code, OLD.nom, NEW.nom, NOW());
        
        ELSIF TG_OP='DELETE' THEN
        INSERT INTO histo_categories(act, oldcode, newcode, oldnom, newnom, date)
        VALUES('DELETE', OLD.code, NULL, OLD.nom, NULL, NOW());
        
        END IF; 
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;");

         $this->execute("CREATE OR REPLACE TRIGGER t_after_update_category
         AFTER INSERT OR UPDATE OR DELETE ON categories
         FOR EACH ROW 
         EXECUTE FUNCTION after_update_category()");


        
    }
      public function down(): void
    {
        $this->execute("DROP TRIGGER t_after_update_category ON categories ");
        $this->execute("DROP FUNCTION after_update_category");
    }
}

